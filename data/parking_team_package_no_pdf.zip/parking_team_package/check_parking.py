#!/usr/bin/env python3
"""Audit and reference calculations for the five original EMT CSV files.

Python 3.10+; standard library only; no network access or source modification.
Usage: python check_parking.py --input-dir data --output-dir reproduced
The source snapshots are identified by SHA-256 in manifest.json.
"""
from __future__ import annotations
import argparse
import calendar
import csv
import datetime as dt
import hashlib
import io
import json
import math
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

FIELDS = ['dateServ', 'hour', 'idParking', 'isEmtPark', 'freeParking', 'parkingSpaces']
KEY = ['dateServ', 'hour', 'idParking']
MONTHS = [f'2026-{m:02}' for m in range(5, 10)]
EMPTY = {'', 'NA', 'N/A', 'NULL', 'NaN', 'nan'}

def avg(values):
    return math.fsum(values) / len(values) if values else None

def quantile(values, p):
    """Linear interpolation: index = (n - 1) * p, as numpy method='linear'."""
    x = sorted(values)
    if not x:
        return None
    h = (len(x) - 1) * p
    a, b = math.floor(h), math.ceil(h)
    return x[a] + (h - a) * (x[b] - x[a])

def numeric_stats(values):
    return dict(n=len(values), mean=avg(values), median=statistics.median(values) if values else None,
                std_sample=statistics.stdev(values) if len(values) > 1 else None,
                min=min(values) if values else None, q1=quantile(values, .25),
                q3=quantile(values, .75), max=max(values) if values else None,
                sum=sum(values) if values else 0)

def write_csv(path, rows, fields=None):
    rows = list(rows)
    fields = fields or (list(rows[0]) if rows else [])
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def convert(field, text):
    if text in EMPTY:
        return None
    if field == 'dateServ':
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', text):
            raise ValueError('date format')
        return dt.date.fromisoformat(text)
    if field == 'isEmtPark':
        if text not in ('True', 'False'):
            raise ValueError('boolean format')
        return text == 'True'
    if not re.fullmatch(r'[+-]?\d+', text):
        raise ValueError('integer format')
    return int(text)

def process(path, month):
    content = path.read_bytes()
    text = content.decode('utf-8-sig', errors='strict')
    reader = csv.reader(io.StringIO(text, newline=''), delimiter=',', strict=True)
    rows, blank_lines, header = [], 0, None
    missing, bad_type = Counter(), Counter()
    for cells in reader:
        if not cells:
            blank_lines += 1
            continue
        if header is None:
            header = cells
            if header != FIELDS:
                raise ValueError(f'{path.name}: unexpected columns {header!r}')
            continue
        if len(cells) != len(FIELDS):
            raise ValueError(f'{path.name}: malformed CSV at physical line {reader.line_num}')
        row = {'source_line': reader.line_num, '_raw': tuple(cells), '_bad_fields': []}
        for field, cell in zip(FIELDS, cells):
            value = cell.strip()
            if value in EMPTY:
                missing[field] += 1
            try:
                row[field] = convert(field, value)
            except ValueError:
                row[field] = None
                bad_type[field] += 1
                row['_bad_fields'].append(field)
        rows.append(row)
    if not rows:
        raise ValueError(f'{path.name}: empty file')
    year, mon = map(int, month.split('-'))
    days = calendar.monthrange(year, mon)[1]
    observed_ids = sorted({r['idParking'] for r in rows if r['idParking'] is not None})
    seen_raw, unique, key_values = set(), [], defaultdict(set)
    for r in rows:
        key = tuple(r[f] for f in KEY)
        key_values[key].add(r['_raw'])
        if r['_raw'] not in seen_raw:
            unique.append(r)
            seen_raw.add(r['_raw'])
    conflicts = {key for key, values in key_values.items() if len(values) > 1}
    exact_dup_extras = len(rows) - len(unique)
    keys = [tuple(r[f] for f in KEY) for r in rows]
    bad_rows, valid = [], []
    for r in unique:
        reasons = []
        date = r['dateServ']
        if any(r[f] is None for f in FIELDS):
            reasons.append('missing_or_invalid_type')
        if date is None or (date.year, date.month) != (year, mon):
            reasons.append('date_outside_month_or_invalid')
        if r['hour'] is None or not 0 <= r['hour'] <= 23:
            reasons.append('hour_outside_0_23_or_invalid')
        if r['idParking'] is None or r['idParking'] <= 0:
            reasons.append('nonpositive_or_invalid_id')
        if r['parkingSpaces'] is None or r['parkingSpaces'] <= 0:
            reasons.append('nonpositive_or_invalid_capacity')
        free, cap = r['freeParking'], r['parkingSpaces']
        if free is not None:
            if free == -1:
                reasons.append('free_equals_minus1')
            elif free < 0:
                reasons.append('other_negative_free')
            if cap is not None and free > cap:
                reasons.append('free_above_capacity')
        if tuple(r[f] for f in KEY) in conflicts:
            reasons.append('conflicting_key')
        r['_reasons'] = reasons
        if not reasons:
            r['occupancy'] = 1 - free / cap
            valid.append(r)
        elif any(s != 'free_equals_minus1' for s in reasons):
            bad_rows.append(r)

    expected_keys = {(dt.date(year, mon, day), hour, park)
                     for day in range(1, days + 1) for hour in range(24) for park in observed_ids}
    actual_keys = set(keys)
    expected = len(expected_keys)
    valid_by_park, raw_by_park, valid_by_hour = defaultdict(list), defaultdict(list), defaultdict(list)
    valid_by_time = defaultdict(list)
    for r in rows:
        raw_by_park[r['idParking']].append(r)
    for r in valid:
        valid_by_park[r['idParking']].append(r)
        valid_by_hour[r['hour']].append(r)
        valid_by_time[(r['dateServ'], r['hour'])].append(r)

    threshold_rows, iqr_records, constant_rows = [], [], []
    for park, obs in sorted(valid_by_park.items()):
        occupancies = [r['occupancy'] for r in obs]
        q1, q3 = quantile(occupancies, .25), quantile(occupancies, .75)
        low, high = q1 - 1.5 * (q3 - q1), q3 + 1.5 * (q3 - q1)
        flagged = [r for r in obs if r['occupancy'] < low or r['occupancy'] > high]
        threshold_rows.append(dict(month=month, idParking=park, n=len(obs), q1=q1, q3=q3,
                                   iqr=q3-q1, lower_fence=low, upper_fence=high, outliers=len(flagged)))
        for r in flagged:
            iqr_records.append(dict(month=month, source_line=r['source_line'], dateServ=r['dateServ'].isoformat(),
                                    hour=r['hour'], idParking=park, freeParking=r['freeParking'],
                                    parkingSpaces=r['parkingSpaces'], occupancy=r['occupancy'],
                                    lower_fence=low, upper_fence=high))
        free_values = [r['freeParking'] for r in obs]
        if len(obs) >= 24 and min(free_values) == max(free_values):
            constant_rows.append(dict(month=month, idParking=park, valid_n=len(obs),
                                      freeParking=free_values[0], parkingSpaces=obs[0]['parkingSpaces'],
                                      isEmtPark=obs[0]['isEmtPark'],
                                      rule='all_valid_values_identical_and_n_ge_24'))
    constant_ids = {r['idParking'] for r in constant_rows}
    parking_rows = []
    for park, obs in sorted(raw_by_park.items()):
        vv = valid_by_park.get(park, [])
        caps = {r['parkingSpaces'] for r in obs}
        flags = {r['isEmtPark'] for r in obs}
        parking_rows.append(dict(month=month, idParking=park, isEmtPark=obs[0]['isEmtPark'],
            raw_n=len(obs), valid_n=len(vv), valid_fraction=len(vv)/len(obs),
            minus1_n=sum(r['freeParking']==-1 for r in obs),
            other_negative_n=sum(r['freeParking'] is not None and r['freeParking'] < -1 for r in obs),
            above_capacity_n=sum(r['freeParking'] is not None and r['parkingSpaces'] is not None and r['freeParking']>r['parkingSpaces'] for r in obs),
            capacity_distinct=len(caps), flag_distinct=len(flags),
            capacity_min=min(c for c in caps if c is not None), capacity_max=max(c for c in caps if c is not None),
            mean_free=avg([r['freeParking'] for r in vv]), mean_occupancy=avg([r['occupancy'] for r in vv]),
            constant_valid_flag=park in constant_ids))
    ranking = sorted([r for r in parking_rows if r['valid_n']], key=lambda r: (-r['mean_occupancy'], r['idParking']))
    hourly = []
    for hour in range(24):
        obs = valid_by_hour[hour]
        hourly.append(dict(month=month, hour=hour, valid_n=len(obs), expected_n=days*len(observed_ids),
                           valid_fraction=len(obs)/(days*len(observed_ids)), mean_free=avg([r['freeParking'] for r in obs]),
                           mean_occupancy=avg([r['occupancy'] for r in obs]),
                           capacity_weighted_occupancy=1-sum(r['freeParking'] for r in obs)/sum(r['parkingSpaces'] for r in obs) if obs else None))
    hour_ranking = sorted([r for r in hourly if r['valid_n']], key=lambda r: (-r['mean_occupancy'], r['hour']))
    group_rows = []
    for flag in (False, True):
        raw_group = [r for r in rows if r['isEmtPark'] == flag]
        valid_group = [r for r in valid if r['isEmtPark'] == flag]
        group_rows.append(dict(month=month, isEmtPark=flag, raw_n=len(raw_group), valid_n=len(valid_group),
                               raw_parks=len({r['idParking'] for r in raw_group}),
                               valid_parks=len({r['idParking'] for r in valid_group}),
                               valid_fraction=len(valid_group)/len(raw_group) if raw_group else None,
                               mean_occupancy=avg([r['occupancy'] for r in valid_group])))
    stat = numeric_stats([r['freeParking'] for r in valid])
    occ_stats = numeric_stats([r['occupancy'] for r in valid])
    sensitivity = [r for r in valid if r['idParking'] not in constant_ids]
    benchmark = dict(month=month, valid_n=len(valid), free_mean=stat['mean'], free_median=stat['median'],
        free_std_sample=stat['std_sample'], free_min=stat['min'], free_q1=stat['q1'], free_q3=stat['q3'], free_max=stat['max'],
        free_sum=stat['sum'], capacity_sum_on_valid=sum(r['parkingSpaces'] for r in valid),
        occupancy_mean=occ_stats['mean'], occupancy_median=occ_stats['median'],
        occupancy_capacity_weighted=1-stat['sum']/sum(r['parkingSpaces'] for r in valid) if valid else None,
        peak_hour=hour_ranking[0]['hour'] if hour_ranking else None,
        peak_hour_all_ties=';'.join(str(r['hour']) for r in hour_ranking if math.isclose(r['mean_occupancy'], hour_ranking[0]['mean_occupancy'], rel_tol=0, abs_tol=1e-12)),
        peak_hour_mean_occupancy=hour_ranking[0]['mean_occupancy'] if hour_ranking else None,
        top_parking_all_ties=';'.join(str(r['idParking']) for r in ranking if math.isclose(r['mean_occupancy'], ranking[0]['mean_occupancy'], rel_tol=0, abs_tol=1e-12)),
        top_parking_mean_occupancy=ranking[0]['mean_occupancy'] if ranking else None,
        valid_zero_n=sum(r['freeParking']==0 for r in valid),
        iqr_flag_n=len(iqr_records), constant_park_ids=';'.join(map(str, sorted(constant_ids))),
        sensitivity_n=len(sensitivity), occupancy_mean_without_constant_parks=avg([r['occupancy'] for r in sensitivity]),
        raw_free_mean_diagnostic_only=avg([r['freeParking'] for r in rows if r['freeParking'] is not None]))
    parsed_dates = [r['dateServ'] for r in rows if r['dateServ'] is not None]
    audit = dict(month=month, file=path.name, bytes=len(content), sha256=hashlib.sha256(content).hexdigest(),
        encoding_rule='utf-8-sig strict; all bytes ASCII' if all(b < 128 for b in content) else 'utf-8-sig strict',
        bom=content.startswith(b'\xef\xbb\xbf'), delimiter=',', blank_lines=blank_lines, physical_lines=len(text.splitlines()),
        data_rows=len(rows), columns=len(header), date_min=min(parsed_dates).isoformat(), date_max=max(parsed_dates).isoformat(),
        days=len(set(parsed_dates)), hours=len({r['hour'] for r in rows}), parks=len(observed_ids), expected_grid_rows=expected,
        missing_grid_keys=len(expected_keys-actual_keys), unexpected_grid_keys=len(actual_keys-expected_keys),
        exact_duplicate_extras=exact_dup_extras, key_duplicate_extras=len(keys)-len(actual_keys),
        conflicting_keys=len(conflicts), missing_cells=sum(missing.values()), type_error_cells=sum(bad_type.values()),
        minus1_n=sum(r['freeParking']==-1 for r in rows), other_negative_n=sum(r['freeParking'] is not None and r['freeParking'] < -1 for r in rows),
        above_capacity_n=sum(r['freeParking'] is not None and r['parkingSpaces'] is not None and r['freeParking']>r['parkingSpaces'] for r in rows),
        nonpositive_capacity_n=sum(r['parkingSpaces'] is not None and r['parkingSpaces']<=0 for r in rows),
        hard_anomaly_n=len(bad_rows), valid_n=len(valid), excluded_n=len(rows)-len(valid), valid_fraction=len(valid)/len(rows),
        valid_parks=len(valid_by_park), parks_without_valid=len(observed_ids)-len(valid_by_park),
        capacity_changed_parks=sum(r['capacity_distinct']>1 for r in parking_rows),
        flag_changed_parks=sum(r['flag_distinct']>1 for r in parking_rows), iqr_flag_n=len(iqr_records))
    field_rows = []
    for field in FIELDS:
        vals = [r[field] for r in rows if r[field] is not None]
        storage = 'string' if field == 'dateServ' else ('boolean' if field == 'isEmtPark' else 'integer')
        field_rows.append(dict(month=month, field=field, csv_storage_type=storage,
                               analytical_type='date' if field=='dateServ' else storage,
                               missing_n=missing[field], invalid_type_n=bad_type[field], distinct_n=len(set(vals)),
                               min=str(min(vals)), max=str(max(vals))))
    anomaly_rows = [dict(month=month, source_line=r['source_line'], **{f: (r[f].isoformat() if isinstance(r[f], dt.date) else r[f]) for f in FIELDS},
                         reasons=';'.join(r['_reasons'])) for r in bad_rows]
    time_rows = [dict(month=month, dateServ=date.isoformat(), hour=hour,
                      valid_n=len(valid_by_time[(date,hour)]), expected_n=len(observed_ids))
                 for date in sorted(set(parsed_dates)) for hour in range(24)]
    return dict(audit=audit, benchmark=benchmark, fields=field_rows, parking=parking_rows, hourly=hourly,
                groups=group_rows, hard_anomalies=anomaly_rows, iqr_thresholds=threshold_rows,
                iqr_records=iqr_records, constant_signals=constant_rows, time_coverage=time_rows)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=Path(__file__).resolve().parent / 'data')
    parser.add_argument('--output-dir', type=Path, default=Path('reproduced'))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs = [process(args.input_dir / f'parking_places_hourly_{month.replace("-", "")}.csv', month) for month in MONTHS]
    for name in ('audit', 'benchmark', 'fields', 'parking', 'hourly', 'groups', 'hard_anomalies', 'iqr_thresholds', 'iqr_records', 'constant_signals', 'time_coverage'):
        rows = [item[name] for item in outputs] if name in ('audit', 'benchmark') else [row for item in outputs for row in item[name]]
        write_csv(args.output_dir / f'{name}.csv', rows)
    reference_rows = []
    questions = [
        ('data_rows', 'Сколько строк данных в исходном CSV (без заголовка и пустой строки)?', 'audit', 'rows', 0),
        ('minus1_n', 'Сколько исходных строк имеют freeParking = -1?', 'audit', 'rows', 0),
        ('other_negative_n', 'Сколько исходных строк имеют freeParking < -1?', 'audit', 'rows', 0),
        ('above_capacity_n', 'Сколько исходных строк имеют freeParking > parkingSpaces?', 'audit', 'rows', 0),
        ('valid_n', 'Сколько строк проходят основной фильтр P1?', 'benchmark', 'rows', 0),
        ('free_mean', 'Каково среднее freeParking после фильтра P1?', 'benchmark', 'spaces', 1e-6),
        ('free_median', 'Какова медиана freeParking после фильтра P1?', 'benchmark', 'spaces', 1e-6),
        ('free_std_sample', 'Каково выборочное стандартное отклонение freeParking после P1 (ddof=1)?', 'benchmark', 'spaces', 1e-6),
        ('free_q1', 'Каков Q1 freeParking после P1 (линейная интерполяция h=(n-1)*0.25)?', 'benchmark', 'spaces', 1e-6),
        ('free_q3', 'Каков Q3 freeParking после P1 (линейная интерполяция h=(n-1)*0.75)?', 'benchmark', 'spaces', 1e-6),
        ('free_max', 'Каков максимум freeParking после фильтра P1?', 'benchmark', 'spaces', 0),
        ('occupancy_mean', 'Каково среднее по строкам 1-freeParking/parkingSpaces после P1?', 'benchmark', 'fraction_0_1', 1e-6),
        ('occupancy_capacity_weighted', 'Каково 1-sum(freeParking)/sum(parkingSpaces) на тех же строках P1?', 'benchmark', 'fraction_0_1', 1e-6),
        ('peak_hour_all_ties', 'Для каких hour среднее по строкам 1-freeParking/parkingSpaces после P1 максимально? Вернуть все часы.', 'benchmark', 'set_of_hours', 0),
        ('peak_hour_mean_occupancy', 'Каково максимальное из 24 почасовых средних долей занятости после P1?', 'benchmark', 'fraction_0_1', 1e-6),
        ('top_parking_all_ties', 'Какие idParking имеют максимальное среднее 1-freeParking/parkingSpaces после P1? Вернуть все ID.', 'benchmark', 'set_of_ids', 0),
        ('iqr_flag_n', 'Сколько допустимых строк отмечено правилом IQR по доле занятости внутри каждой пары месяц/парковка? Они сохраняются в P1.', 'benchmark', 'rows', 0),
    ]
    for item in outputs:
        for metric, question, source, unit, tolerance in questions:
            reference_rows.append(dict(month=item['audit']['month'], metric=metric, question_ru=question,
                expected_value=item[source][metric], unit=unit, absolute_tolerance=tolerance,
                processing_rule='P1: all fields valid; date in month; hour 0..23; id>0; capacity>0; 0<=free<=capacity; exact duplicates keep first; conflicting keys exclude all; IQR and constant values retained'))
    write_csv(args.output_dir / 'reference_answers.csv', reference_rows)
    parking_by_month = [{r['idParking']: r for r in item['parking']} for item in outputs]
    all_ids = set.union(*(set(rows) for rows in parking_by_month))
    cross_month = dict(total_data_rows=sum(item['audit']['data_rows'] for item in outputs),
        total_valid_rows=sum(item['audit']['valid_n'] for item in outputs), unique_parks=len(all_ids),
        same_parking_ids=all(set(rows)==all_ids for rows in parking_by_month),
        capacities_stable_across_months=all(len({rows[park]['capacity_min'] for rows in parking_by_month if park in rows})==1
            and all(rows[park]['capacity_distinct']==1 for rows in parking_by_month if park in rows) for park in all_ids),
        flags_stable_across_months=all(len({rows[park]['isEmtPark'] for rows in parking_by_month if park in rows})==1
            and all(rows[park]['flag_distinct']==1 for rows in parking_by_month if park in rows) for park in all_ids),
        all_months_without_valid_ids=sorted(park for park in all_ids if all(rows.get(park,{}).get('valid_n',0)==0 for rows in parking_by_month)),
        fleet_capacity_first_month=sum(r['capacity_min'] for r in outputs[0]['parking']))
    result = {'script_version': '1.0', 'python_version': sys.version.split()[0],
              'months': [dict(audit=item['audit'], benchmark=item['benchmark']) for item in outputs],
              'cross_month': cross_month,
              'policy': {'missing_tokens_after_strip': sorted(EMPTY), 'full_duplicates': 'keep first exact raw record',
                         'conflicting_keys': 'exclude all competing records',
                         'valid_free_rule': 'all fields parse; date in file month; hour 0..23; id>0; capacity>0; 0<=free<=capacity',
                         'minus1_semantics': 'invalid count; excluded. Official semantic description unavailable.',
                         'std_ddof': 1, 'quantile': 'linear, h=(n-1)*p', 'occupancy': '1-freeParking/parkingSpaces',
                         'iqr': 'within month and parking on valid occupancy, strict outside Q1-1.5*IQR or Q3+1.5*IQR',
                         'iqr_flags_removed': False, 'constant_signals_removed_from_primary': False,
                         'constant_signal_rule': 'all valid free values identical and valid n>=24',
                         'ranking_ties_absolute_tolerance': 1e-12}}
    (args.output_dir / 'audit_results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    original_manifest = Path(__file__).resolve().parent / 'manifest.json'
    if original_manifest.exists():
        expected = json.loads(original_manifest.read_text(encoding='utf-8'))['data']
        checks = {item['audit']['file']: item['audit']['sha256']==expected[item['audit']['file']]['sha256'] for item in outputs}
        (args.output_dir / 'snapshot_check.json').write_text(json.dumps(checks, indent=2), encoding='utf-8')
        if not all(checks.values()):
            print('WARNING: input bytes differ from original snapshots; see snapshot_check.json', file=sys.stderr)
    print(json.dumps([item['audit'] for item in outputs], ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
