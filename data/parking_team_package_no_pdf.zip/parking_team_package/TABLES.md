# Словарь результатов

Все таблицы рассчитаны `check_parking.py`, версия 1.0. Месяц записан как YYYY-MM. Основной фильтр **P1**: все поля разобраны; дата в месяце файла; hour 0-23; idParking>0; parkingSpaces>0; 0<=freeParking<=parkingSpaces. Точные дубли сохраняются по первому экземпляру, конфликтующие ключи исключаются целиком. Фактически дублей и ошибок разбора нет. Все -1 и прочие отрицательные значения исключены, нули сохранены. IQR-флаги и постоянные допустимые значения в P1 сохраняются.

Результаты CSV: UTF-8 с BOM, разделитель `,`, десятичный знак `.`. Пустая ячейка результата означает «показатель не определён», например среднее для ID без допустимых строк. Это не исходный пропуск. Доли лежат в 0-1. Суффикс `_n` означает число записей, `_fraction` - долю. Булевы значения: True/False. Списки ID и часов внутри ячейки разделены `;` и отсортированы по возрастанию.

## audit.csv - 5 строк

| Столбцы | Значение |
| --- | --- |
| month, file, bytes, sha256 | Месяц, имя файла, размер в байтах, контрольная сумма исходных байтов |
| encoding_rule, bom, delimiter | Правило декодирования, наличие BOM, разделитель |
| blank_lines, physical_lines | Пустые CSV-строки и физические строки, включая пустую строку и заголовок |
| data_rows, columns | Записи данных без пустой строки/заголовка; число столбцов |
| date_min, date_max, days, hours, parks | Границы дат и число различных дат/часов/ID в исходнике |
| expected_grid_rows | Дней в месяце × 24 × число наблюдаемых ID |
| missing_grid_keys, unexpected_grid_keys | Отсутствующие и лишние ключи относительно ожидаемой сетки |
| exact_duplicate_extras, key_duplicate_extras | Число лишних повторов полной записи / ключа |
| conflicting_keys | Число ключей с разными записями |
| missing_cells, type_error_cells | Число пустых/служебных пустых ячеек и ошибок строгого разбора |
| minus1_n, other_negative_n | Исходные freeParking=-1 и freeParking<-1 |
| above_capacity_n, nonpositive_capacity_n | Исходные freeParking>parkingSpaces; parkingSpaces<=0 |
| hard_anomaly_n | Недопустимые уникальные строки с иной причиной, кроме единственной причины freeParking=-1 |
| valid_n, excluded_n, valid_fraction | Число P1, число исходных строк вне P1, доля P1 от всех исходных строк |
| valid_parks, parks_without_valid | ID хотя бы с одним P1 / без P1 |
| capacity_changed_parks, flag_changed_parks | ID с несколькими вместимостями / флагами внутри месяца |
| iqr_flag_n | Число P1, отмеченных правилом IQR (не исключаются) |

## benchmark.csv - 5 строк

| Столбец | Определение / единица |
| --- | --- |
| valid_n | Число строк P1 |
| free_mean, free_median | Среднее и медиана freeParking, места |
| free_std_sample | Выборочное стандартное отклонение, ddof=1, места |
| free_min, free_max | Минимум/максимум свободных мест после P1 |
| free_q1, free_q3 | Квартили: линейная интерполяция h=(n-1)*p, места |
| free_sum | Сумма freeParking по P1; сумма повторных почасовых измерений, не размер фонда |
| capacity_sum_on_valid | Сумма parkingSpaces по тем же P1; повторяющиеся вместимости |
| occupancy_mean, occupancy_median | Среднее/медиана по строкам occupancy=1-freeParking/parkingSpaces, доли |
| occupancy_capacity_weighted | 1-free_sum/capacity_sum_on_valid, доля |
| peak_hour | Первый час среди максимумов (минимальный при ничьей) |
| peak_hour_all_ties | Все hour с максимальным средним occupancy, допуск 1e-12 |
| peak_hour_mean_occupancy | Значение максимального почасового среднего, доля |
| top_parking_all_ties | Все ID с максимальным средним occupancy, допуск 1e-12 |
| top_parking_mean_occupancy | Значение максимального среднего по ID, доля |
| valid_zero_n | Число P1 с freeParking=0 |
| iqr_flag_n | Число статистических IQR-флагов среди P1 |
| constant_park_ids | ID со всеми одинаковыми допустимыми freeParking и n>=24 |
| sensitivity_n | P1 без целых пар месяц/ID из constant_park_ids |
| occupancy_mean_without_constant_parks | Среднее occupancy в дополнительной проверке чувствительности, доля |
| raw_free_mean_diagnostic_only | Диагностическое среднее исходного freeParking со всеми отрицательными и превышениями. НЕ эталон доступности парковок |

## reference_answers.csv - 85 строк

17 готовых задач на месяц. `question_ru` - вопрос, `metric` - показатель, `expected_value` - ответ; `unit` - единица (rows, spaces, fraction_0_1, set_of_hours, set_of_ids), `absolute_tolerance` - абсолютный допуск, `processing_rule` - договорённость P1. Счётчики и множества сравниваются точно. Для множеств порядок не влияет; все ничьи должны присутствовать. Доли нельзя сравнивать с процентами без преобразования.

## fields.csv - 30 строк

Аудит шести полей каждого месяца. `field` - имя; `csv_storage_type` - вид фактических значений, а не встроенный тип CSV; `analytical_type` - тип после разбора. `missing_n`, `invalid_type_n`, `distinct_n` - пропуски, ошибки разбора, различные значения. `min`, `max` - границы среди разобранных значений; для bool порядок False<True.

## parking.csv - 410 строк

По всем 82 ID каждого месяца, в том числе без P1. `raw_n`, `valid_n`, `valid_fraction` - покрытие. `minus1_n`, `other_negative_n`, `above_capacity_n` - исходные причины недопустимости. `capacity_distinct`, `flag_distinct` - количество разных вместимостей/флагов; `capacity_min`, `capacity_max` - вместимость. `mean_free`, `mean_occupancy` - средние по P1; пусты, если valid_n=0. `constant_valid_flag` - правило постоянства среди P1 при n>=24. Рейтинг следует строить по mean_occupancy, а не по вместимости или номеру ID.

## hourly.csv - 120 строк

24 hour на месяц. `expected_n`=дни месяца×82; `valid_n`, `valid_fraction` - покрытие. `mean_free`, `mean_occupancy`, `capacity_weighted_occupancy` - показатели P1 данного часа за все дни и ID. `hour` - исходная метка, часовой пояс не преобразуется.

## groups.csv - 10 строк

Группы isEmtPark False/True каждого месяца. `raw_n`, `valid_n`, `raw_parks`, `valid_parks`, `valid_fraction` - покрытие; `mean_occupancy` - среднее по строкам P1. Значение False не раскрывает оператора или географию парковки.

## time_coverage.csv - 3 672 строки

Каждая пара dateServ/hour: `expected_n`=82 и `valid_n` по P1. Позволяет увидеть часы без измерений, которые не выявляет проверка числа исходных строк. 26.08.2026, часы 4-9: valid_n=0.

## hard_anomalies.csv - 694 строки

Недопустимые уникальные записи с причиной помимо отдельного -1. Включены исходные поля, `reasons`, `source_line`. Физическая строка считается с 1, включая начальную пустую строку и заголовок. Причины `other_negative_free` и `free_above_capacity` встречаются в текущих файлах. Полный массив -1 не дублируется отдельным большим файлом: счётчики по месяцам и ID есть в audit.csv и parking.csv, сами записи находятся в исходниках.

## iqr_thresholds.csv - 150 строк; iqr_records.csv - 1 538 строк

Порог IQR отдельно в каждой паре месяц/ID с P1. `q1`, `q3`, `iqr`, `lower_fence`, `upper_fence` относятся к occupancy. Нижняя граница Q1-1.5*IQR, верхняя Q3+1.5*IQR. `outliers` - число значений строго за границами. В iqr_records.csv есть исходные поля, occupancy, границы и физическая строка. Эти наблюдения остаются в основных эталонах.

## constant_signals.csv - 11 строк

Пары месяц/ID, для которых все допустимые freeParking одинаковы и valid_n>=24. Показаны n, значение free, вместимость и флаг. Постоянство не означает отсутствия -1 в исходных записях этого ID и не доказывает неисправность датчика. В P1 такие записи сохраняются.

## JSON и контрольные суммы

- `tables/audit_results.json`: все основные месячные результаты, правила и проверки между месяцами, версия Python.
- `tables/snapshot_check.json`: пять результатов сравнения входных SHA-256 с manifest.json (все true).
- `manifest.json`: точные размеры, SHA-256 и официальные ссылки для каждого исходного файла; дата фиксации 14.10.2026.
- `source_verification.json`: журнал загрузок официальных файлов и сравнения байтов. Для июня одна попытка через городской каталог, для августа одна прямая попытка EMT завершились сетевым тайм-аутом; альтернативная официальная загрузка каждого файла успешно подтверждена. Это не отсутствие источника.
- `validation.json`: 2 153 успешные независимые проверки pandas/NumPy и побайтное совпадение повторного расчёта 13 файлов результатов.
- `CHECKSUMS.sha256`: контрольные суммы всех доставленных файлов, кроме самого списка и внешнего ZIP.
